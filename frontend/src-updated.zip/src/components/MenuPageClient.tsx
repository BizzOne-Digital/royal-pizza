"use client";

import { AnimatePresence, motion } from "framer-motion";
import Image from "next/image";
import { useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import {
  BEVERAGES_LIST,
  BUILD_YOUR_OWN_TIERS,
  BUILD_YOUR_OWN_PASTA,
  BYO_EXTRAS,
  BYO_TOPPING_PRICING,
  BYO_TOPPINGS,
  DESSERTS,
  DIPS_LIST,
  GARLIC_BREADS,
  MENU_CATEGORY_TABS,
  type MenuCategoryId,
  PASTA_ADDONS,
  PASTA_EXTRAS,
  PASTAS,
  PIZZA_SIZE_LEGEND,
  SALADS,
  SANDWICHES,
  SIDES,
  SIGNATURE_PASTAS,
  SIGNATURE_PIZZAS,
  SPECIALTY_PIZZAS,
  STARTERS,
  SUBS,
  SUB_EXTRAS,
  WING_SAUCES,
  WINGS,
} from "@/data/menu";
import { MENU_INTRO } from "@/data/site-content";
import { CategoryTabs } from "./CategoryTabs";
import { SimpleItemCard, SpecialtyPizzaCard } from "./MenuCard";

const panelTransition = { duration: 0.38, ease: [0.22, 1, 0.36, 1] as const };

const CATEGORY_IMAGES: Record<string, { src: string; alt: string }> = {
  starters: {
    src: "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?w=1400&q=80",
    alt: "Delicious starters and appetizers",
  },
  pizzas: {
    src: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=1400&q=80",
    alt: "Fresh baked specialty pizza",
  },
  "signature-pizzas": {
    src: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=1400&q=80",
    alt: "Signature gourmet pizzas",
  },
  "build-your-own": {
    src: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=1400&q=80",
    alt: "Build your own pizza toppings",
  },
  subs: {
    src: "https://images.unsplash.com/photo-1555072956-7758afb20e8f?w=1400&q=80",
    alt: "Loaded toasted sub sandwich",
  },
  pastas: {
    src: "https://images.unsplash.com/photo-1595295333158-4742f28fbd85?w=1400&q=80",
    alt: "Rich creamy pasta dish",
  },
  "garlic-breads": {
    src: "https://images.unsplash.com/photo-1619531040576-f9416740661f?w=1400&q=80",
    alt: "Golden oven-baked garlic bread",
  },
  wings: {
    src: "https://images.unsplash.com/photo-1567620832903-9fc6debc209f?w=1400&q=80",
    alt: "Saucy crispy chicken wings",
  },
  salads: {
    src: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=1400&q=80",
    alt: "Fresh crisp salad bowl",
  },
  sides: {
    src: "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?w=1400&q=80",
    alt: "Assorted sides and dips",
  },
  desserts: {
    src: "https://images.unsplash.com/photo-1551024601-bec78aea704b?w=1400&q=80",
    alt: "Delicious desserts",
  },
  "drinks-dips": {
    src: "https://images.unsplash.com/photo-1544145945-f90425340c7e?w=1400&q=80",
    alt: "Cold drinks and dipping sauces",
  },
};

const CATEGORY_TAGLINES: Record<string, string> = {
  starters: "The perfect way to begin — shareable, crispy, and deeply satisfying.",
  pizzas: "Stone-baked to perfection — crisp where it counts, soft where it matters.",
  "signature-pizzas": "Elevated combinations — our chef's most distinctive creations.",
  "build-your-own": "Your crust. Your sauce. Your toppings. Built your way.",
  subs: "Loaded, toasted, and dressed like a main course.",
  pastas: "Baked until the cheese sings — rich, hearty, and deeply satisfying.",
  "garlic-breads": "Kissed with butter and herbs — golden right out of the oven.",
  wings: "Sauced to order. Every bite packs a punch.",
  salads: "Fresh, crisp bowls that actually fill you up.",
  sides: "The perfect companions — never an afterthought.",
  desserts: "Finish it right. Sweet notes to close the feast.",
  "drinks-dips": "Cold drinks and bold dips to round out every order.",
};

function matches(q: string, ...parts: (string | undefined)[]) {
  if (!q.trim()) return true;
  const needle = q.toLowerCase();
  return parts.some((p) => (p ?? "").toLowerCase().includes(needle));
}

function CategoryHero({ categoryId }: { categoryId: string }) {
  const img = CATEGORY_IMAGES[categoryId];
  const tagline = CATEGORY_TAGLINES[categoryId];
  if (!img) return null;

  return (
    <motion.div
      key={categoryId}
      initial={{ opacity: 0, scale: 1.03 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.55 }}
      className="relative mb-10 overflow-hidden rounded-2xl border border-gold/20"
      style={{ height: 220 }}
    >
      <Image
        src={img.src}
        alt={img.alt}
        fill
        className="object-cover object-center"
        sizes="(max-width:768px) 100vw, 1152px"
        priority
      />
      <div className="absolute inset-0 bg-gradient-to-r from-charcoal/92 via-charcoal/60 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal/40 to-transparent" />
      <div className="absolute inset-0 flex flex-col justify-end p-6 md:p-8">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.2 }}
          className="max-w-lg text-sm text-cream/85 md:text-base"
        >
          {tagline}
        </motion.p>
      </div>
    </motion.div>
  );
}

export function MenuPageClient() {
  const searchParams = useSearchParams();
  const [active, setActive] = useState<MenuCategoryId>("starters");
  const [q, setQ] = useState("");

  useEffect(() => {
    const raw = searchParams?.get("category");
    if (!raw) return;
    const ok = MENU_CATEGORY_TABS.some((t) => t.id === raw);
    if (ok) setActive(raw as MenuCategoryId);
  }, [searchParams]);

  const filteredPizzas = useMemo(
    () =>
      SPECIALTY_PIZZAS.filter((p) =>
        matches(q, p.name, p.toppings, p.sauce, p.drizzle, p.choiceOfDrizzle),
      ),
    [q],
  );

  const filteredSignaturePizzas = useMemo(
    () =>
      SIGNATURE_PIZZAS.filter((p) =>
        matches(q, p.name, p.toppings),
      ),
    [q],
  );

  const byoHaystack = useMemo(() => {
    const toppings = [
      ...BYO_TOPPINGS.sauces,
      ...BYO_TOPPINGS.additionalCheeses,
      ...BYO_TOPPINGS.vegetarian,
      ...BYO_TOPPINGS.nonVegetarian,
    ].join(" ");
    const extras = BYO_EXTRAS.map((e) => e.name).join(" ");
    const tiers = BUILD_YOUR_OWN_TIERS.map((t) => t.label).join(" ");
    return `${tiers} ${toppings} ${extras} ${PIZZA_SIZE_LEGEND}`;
  }, []);

  const showByo = matches(q, "build", "topping", "cheese", "sauce", byoHaystack);

  function filterSimple(list: typeof SUBS) {
    return list.filter((i) => matches(q, i.name, i.description));
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: panelTransition.ease }}
        className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between"
      >
        <div>
          <h1 className="font-display text-3xl text-gold md:text-4xl">Build Your Order, Your Way</h1>
          <p className="mt-2 max-w-xl text-sm text-cream/75">
            Explore the full menu with ease: filter by category, search exactly what you're craving, and plan your order before you even arrive.
          </p>
        </div>
        <label className="block w-full md:max-w-xs">
          <span className="sr-only">Search menu</span>
          <motion.input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search items…"
            whileFocus={{ scale: 1.02, boxShadow: "0 0 0 2px rgba(201,154,58,0.35)" }}
            className="w-full rounded-md border border-gold/35 bg-charcoal px-4 py-2.5 text-sm text-cream placeholder:text-cream/40 outline-none ring-gold/30 transition-shadow"
          />
        </label>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-40px" }}
        transition={{ duration: 0.55 }}
        className="mb-10 rounded-xl border border-gold/25 bg-gradient-to-br from-charcoal/95 via-charcoal/85 to-umber/30 p-6 shadow-[0_0_60px_rgba(201,154,58,0.08)] md:p-8"
      >
        <h2 className="font-display text-xl text-gold md:text-2xl">
          {MENU_INTRO.title}
        </h2>
        <div className="mt-4 max-w-4xl space-y-3 text-sm leading-relaxed text-cream/80 md:text-base">
          {MENU_INTRO.paras.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
        <h3 className="mt-8 font-display text-lg text-gold">
          {MENU_INTRO.appetiteTitle}
        </h3>
        <div className="mt-3 max-w-4xl space-y-3 text-sm leading-relaxed text-cream/80 md:text-base">
          {MENU_INTRO.appetiteBody.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
        <h3 className="mt-8 font-display text-lg text-gold">
          {MENU_INTRO.tipsTitle}
        </h3>
        <ul className="mt-3 max-w-3xl space-y-2 text-sm text-cream/75">
          {MENU_INTRO.tips.map((t) => (
            <li key={t} className="flex items-start gap-2">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-gold" />
              {t}
            </li>
          ))}
        </ul>
      </motion.div>

      <CategoryTabs active={active} onChange={setActive} />

      <AnimatePresence mode="wait">

        {/* ── STARTERS ── */}
        {active === "starters" ? (
          <motion.section key="starters" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} className="mt-10 space-y-6">
            <CategoryHero categoryId="starters" />
            <h2 className="font-display text-2xl text-cream">Starters</h2>
            <div className="space-y-3">{filterSimple(STARTERS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>

            <h3 className="font-display text-xl text-gold">Sides</h3>
            <div className="space-y-3">{filterSimple(SIDES).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>
          </motion.section>
        ) : null}

        {/* ── CLASSIC PIZZAS ── */}
        {active === "pizzas" ? (
          <motion.section key="pizzas" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-pizzas" className="mt-10 space-y-6">
            <CategoryHero categoryId="pizzas" />
            <h2 id="menu-pizzas" className="font-display text-2xl text-cream">Classic Pizzas</h2>
            <p className="text-sm text-cream/65">{PIZZA_SIZE_LEGEND}</p>
            <div className="grid gap-5 md:grid-cols-2">
              {filteredPizzas.map((p) => (
                <SpecialtyPizzaCard key={p.id} pizza={p} />
              ))}
            </div>
            {filteredPizzas.length === 0 ? (
              <p className="text-cream/60">No pizzas match your search.</p>
            ) : null}
          </motion.section>
        ) : null}

        {/* ── SIGNATURE PIZZAS ── */}
        {active === "signature-pizzas" ? (
          <motion.section key="sig-pizzas" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} className="mt-10 space-y-6">
            <CategoryHero categoryId="signature-pizzas" />
            <h2 className="font-display text-2xl text-cream">Signature Pizzas</h2>
            <p className="text-sm text-cream/65">Available in Small & Medium only</p>
            <div className="grid gap-5 md:grid-cols-2">
              {filteredSignaturePizzas.map((p) => (
                <div key={p.id} className="rounded-xl border border-gold/25 bg-charcoal/70 p-5 space-y-3">
                  <h3 className="font-display text-lg text-gold">{p.name}</h3>
                  <p className="text-sm text-cream/80">{p.toppings}</p>
                  <div className="flex gap-4 text-sm">
                    {p.prices.map((pr) => (
                      <span key={pr.label} className="text-cream/70">
                        <span className="text-cream/50">{pr.label} </span>
                        <span className="font-semibold text-gold">${pr.amount.toFixed(2)}</span>
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            {filteredSignaturePizzas.length === 0 ? (
              <p className="text-cream/60">No signature pizzas match your search.</p>
            ) : null}
          </motion.section>
        ) : null}

        {/* ── BUILD YOUR OWN PIZZA ── */}
        {active === "build-your-own" && showByo ? (
          <motion.section key="byo" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-byo" className="mt-10 space-y-6">
            <CategoryHero categoryId="build-your-own" />
            <h2 id="menu-byo" className="font-display text-2xl text-cream">Build your own pizza</h2>

            <div className="rounded-lg border border-gold/25 bg-charcoal/70 p-5 text-sm">
              <h3 className="font-display text-lg text-gold mb-3">Base Prices (Includes Mozzarella Cheese)</h3>
              <div className="flex flex-wrap gap-3">
                {BUILD_YOUR_OWN_TIERS.map((row) => (
                  <div key={row.label} className="flex flex-col items-center gap-1 rounded-md border border-gold/20 px-4 py-3 bg-charcoal/50">
                    <span className="text-cream/70 text-xs">{row.label}</span>
                    <div className="flex gap-3 text-xs text-cream/60">
                      <span>S <span className="text-gold font-semibold">${row.prices.S.toFixed(2)}</span></span>
                      <span>M <span className="text-gold font-semibold">${row.prices.M.toFixed(2)}</span></span>
                      <span>L <span className="text-gold font-semibold">${row.prices.L.toFixed(2)}</span></span>
                      <span>XL <span className="text-gold font-semibold">${row.prices.XL.toFixed(2)}</span></span>
                      <span>P <span className="text-gold font-semibold">${row.prices.P.toFixed(2)}</span></span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-lg border border-gold/20 bg-amber-900/10 p-5 text-sm space-y-1">
              <h3 className="font-display text-base text-gold">Topping Pricing</h3>
              <p className="text-cream/75">First 4 toppings: <span className="text-gold font-semibold">{BYO_TOPPING_PRICING.firstFour}</span></p>
              <p className="text-cream/75">Additional toppings: <span className="text-gold font-semibold">{BYO_TOPPING_PRICING.additional}</span></p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              {[
                { title: "Sauces (count as 1 topping)", items: BYO_TOPPINGS.sauces },
                { title: "Additional Cheeses (count as 1 topping each)", items: BYO_TOPPINGS.additionalCheeses },
                { title: "Vegetarian Toppings", items: BYO_TOPPINGS.vegetarian },
                { title: "Non-Vegetarian Toppings", items: BYO_TOPPINGS.nonVegetarian },
              ].map(({ title, items }) => (
                <div key={title} className="rounded-lg border border-gold/25 bg-charcoal/70 p-5">
                  <h3 className="font-display text-lg text-gold">{title}</h3>
                  <p className="mt-2 text-sm text-cream/85">{items.join(", ")}.</p>
                </div>
              ))}
            </div>
          </motion.section>
        ) : null}

        {active === "build-your-own" && !showByo ? (
          <motion.p key="byo-empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mt-10 text-cream/60">
            No build-your-own items match your search.
          </motion.p>
        ) : null}

        {/* ── SUBS & SANDWICHES ── */}
        {active === "subs" ? (
          <motion.section key="subs" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-subs" className="mt-10 space-y-6">
            <CategoryHero categoryId="subs" />
            <h2 id="menu-subs" className="font-display text-2xl text-cream">Sandwiches</h2>
            <p className="text-sm text-cream/65">Comes with a choice of Side — Fries, Onion Rings or Wedges</p>
            <div className="space-y-3">{filterSimple(SANDWICHES).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>

            <h3 className="font-display text-xl text-gold mt-4">Submarines (Foot Long)</h3>
            <div className="space-y-3">{filterSimple(SUBS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>

            <h3 className="font-display text-xl text-gold">Sub Extras</h3>
            <div className="space-y-3">{filterSimple(SUB_EXTRAS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>
          </motion.section>
        ) : null}

        {/* ── PASTAS ── */}
        {active === "pastas" ? (
          <motion.section key="pastas" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-pastas" className="mt-10 space-y-6">
            <CategoryHero categoryId="pastas" />
            <h2 id="menu-pastas" className="font-display text-2xl text-cream">Pastas</h2>
            <div className="space-y-3">{filterSimple(PASTAS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>

            <h3 className="font-display text-xl text-gold">Signature Pastas</h3>
            <div className="space-y-3">{filterSimple(SIGNATURE_PASTAS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>

            <h3 className="font-display text-xl text-gold">Pasta Add-Ons</h3>
            <div className="space-y-3">{filterSimple(PASTA_ADDONS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>

            {/* Build Your Own Pasta */}
            <div className="rounded-xl border border-gold/25 bg-charcoal/70 p-6 space-y-4">
              <h3 className="font-display text-xl text-gold">
                Build Your Own Pasta
                <span className="ml-3 text-base font-normal text-cream/60">Starting at ${BUILD_YOUR_OWN_PASTA.startingAt.toFixed(2)}</span>
              </h3>
              <div className="grid gap-4 md:grid-cols-2">
                {[
                  { label: "Choose Your Pasta", items: BUILD_YOUR_OWN_PASTA.pastas },
                  { label: "Choose Your Sauce", items: BUILD_YOUR_OWN_PASTA.sauces },
                  { label: "Add Protein", items: BUILD_YOUR_OWN_PASTA.proteins },
                  { label: "Way to Cook", items: BUILD_YOUR_OWN_PASTA.wayToCook },
                ].map(({ label, items }) => (
                  <div key={label} className="rounded-lg border border-gold/15 bg-charcoal/50 p-4">
                    <h4 className="font-semibold text-gold text-sm mb-2">{label}</h4>
                    <ul className="space-y-1">
                      {items.map((item) => (
                        <li key={item} className="text-sm text-cream/80 flex items-start gap-2">
                          <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-gold/60" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </motion.section>
        ) : null}

        {/* ── GARLIC BREADS ── */}
        {active === "garlic-breads" ? (
          <motion.section key="garlic" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-garlic" className="mt-10 space-y-6">
            <CategoryHero categoryId="garlic-breads" />
            <h2 id="menu-garlic" className="font-display text-2xl text-cream">Garlic Breads</h2>
            <div className="space-y-3">{filterSimple(GARLIC_BREADS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>
          </motion.section>
        ) : null}

        {/* ── WINGS ── */}
        {active === "wings" ? (
          <motion.section key="wings" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-wings" className="mt-10 space-y-6">
            <CategoryHero categoryId="wings" />
            <h2 id="menu-wings" className="font-display text-2xl text-cream">Wings</h2>
            <div className="rounded-lg border border-gold/20 bg-charcoal/60 px-5 py-4 text-sm">
              <span className="font-semibold text-gold">Available sauces: </span>
              <span className="text-cream/80">{WING_SAUCES}</span>
            </div>
            <div className="space-y-3">{filterSimple(WINGS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>
          </motion.section>
        ) : null}

        {/* ── SALADS ── */}
        {active === "salads" ? (
          <motion.section key="salads" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-salads" className="mt-10 space-y-6">
            <CategoryHero categoryId="salads" />
            <h2 id="menu-salads" className="font-display text-2xl text-cream">Salads</h2>
            <div className="space-y-3">{filterSimple(SALADS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>
          </motion.section>
        ) : null}

        {/* ── SIDES ── */}
        {active === "sides" ? (
          <motion.section key="sides" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-sides" className="mt-10 space-y-6">
            <CategoryHero categoryId="sides" />
            <h2 id="menu-sides" className="font-display text-2xl text-cream">Sides</h2>
            <div className="space-y-3">{filterSimple(SIDES).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>
            <div className="rounded-lg border border-gold/25 bg-charcoal/70 p-5 text-sm text-cream/85">
              <h3 className="font-display text-lg text-gold">Dips</h3>
              <p className="mt-2">{DIPS_LIST}</p>
            </div>
            <div className="rounded-lg border border-gold/25 bg-charcoal/70 p-5 text-sm text-cream/85">
              <h3 className="font-display text-lg text-gold">Beverages</h3>
              <p className="mt-2">{BEVERAGES_LIST}</p>
            </div>
          </motion.section>
        ) : null}

        {/* ── DESSERTS ── */}
        {active === "desserts" ? (
          <motion.section key="desserts" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-desserts" className="mt-10 space-y-6">
            <CategoryHero categoryId="desserts" />
            <h2 id="menu-desserts" className="font-display text-2xl text-cream">Desserts</h2>
            <div className="space-y-3">{filterSimple(DESSERTS).map((i) => <SimpleItemCard key={i.id} item={i} />)}</div>
          </motion.section>
        ) : null}

        {/* ── DRINKS & DIPS ── */}
        {active === "drinks-dips" ? (
          <motion.section key="drinks" role="tabpanel" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={panelTransition} aria-labelledby="menu-drinks" className="mt-10 space-y-6">
            <CategoryHero categoryId="drinks-dips" />
            <h2 id="menu-drinks" className="font-display text-2xl text-cream">Drinks & Dips</h2>
            <div className="grid gap-5 md:grid-cols-2">
              <div className="rounded-lg border border-gold/25 bg-charcoal/70 p-6 text-sm text-cream/85">
                <h3 className="font-display text-lg text-gold">Dips</h3>
                <p className="mt-2">{DIPS_LIST}</p>
              </div>
              <div className="rounded-lg border border-gold/25 bg-charcoal/70 p-6 text-sm text-cream/85">
                <h3 className="font-display text-lg text-gold">Beverages</h3>
                <p className="mt-2">{BEVERAGES_LIST}</p>
              </div>
            </div>
          </motion.section>
        ) : null}

      </AnimatePresence>
    </div>
  );
}
